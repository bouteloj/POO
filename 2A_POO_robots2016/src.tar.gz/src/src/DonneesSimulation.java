package src;

import java.util.LinkedList;

public class DonneesSimulation {
	private Carte map;
	private LinkedList<Robot> robots;
	private LinkedList<Incendie> incendies;
}

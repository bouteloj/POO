package simulateur;

import src.DonneesSimulation;
import gui.Simulable;

public class Simulateur implements Simulable {
	public DonneesSimulation data;
	
	@Override
	public void next() {
		// TODO Auto-generated method stub

	}

	@Override
	public void restart() {
		// TODO Auto-generated method stub

	}

}
